# PROC47-1_4-plantilla-proyecto
Juego Campo de tiro. Etapa 1.  

Modificación por parte del alumno en dos secciones diferentes  

### Nombre en Inglés: project-template-for-shooting-range
